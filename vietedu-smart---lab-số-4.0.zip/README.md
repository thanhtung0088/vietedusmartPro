# 🎓 VIETEDU SMART - LAB SỐ 4.0

Hệ sinh thái giáo dục số thông minh dành cho Giáo viên Việt Nam.

## Tính năng
- Soạn bài AI chuẩn 5512.
- Sổ điểm điện tử & Nhận xét AI.
- Quản trị nhà trường Lab Số Modern.
- Game Center học tập.
- Thời khóa biểu thông minh.

## Công nghệ
- React 19 + TypeScript.
- Google Gemini 3 Flash.
- Tailwind CSS.
