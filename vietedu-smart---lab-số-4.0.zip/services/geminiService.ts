
import { GoogleGenAI, Type } from "@google/genai";

// Khởi tạo client Google GenAI bằng API key từ biến môi trường.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_PROMPT = `Bạn là Trợ lý AI Toàn năng của Hệ sinh thái Giáo dục VietEdu Smart (Phiên bản Lab Số 4.0).
Nhiệm vụ của bạn:
1. Hỗ trợ giáo viên soạn giáo án chuẩn 5512, đề kiểm tra 7991, rubrics đánh giá.
2. Tư vấn phương pháp sư phạm hiện đại, ứng dụng CNTT vào giảng dạy.
3. Giải đáp các thắc mắc về quản lý hồ sơ chuyên môn, sổ điểm, sổ chủ nhiệm.
4. Trợ giúp Ban giám hiệu soạn thảo thời khóa biểu khoa học, tối ưu.
5. Trả lời bằng ngôn ngữ sư phạm, chuyên nghiệp, khích lệ và ngắn gọn.
6. Luôn xưng hô là "Trợ lý VietEdu" và gọi người dùng là "Thầy/Cô".`;

export const chatWithAI = async (msg: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: msg,
    config: {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
    }
  });
  return response.text;
};

export const scanTimetableImage = async (base64Data: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/png',
            data: base64Data,
          },
        },
        { text: "Hãy phân tích ảnh thời khóa biểu này. TRÍCH XUẤT TOÀN BỘ CÁC TIẾT DẠY. Cấu trúc bảng gồm các cột Thứ (Hai-Bảy) và các hàng Tiết (1-5 sáng/chiều). TRẢ VỀ JSON MẢNG: { dayOfWeek: number (2-7), period: number (1-5), isMorning: boolean, subject: string, class: string }. Ví dụ: GDCD - 6.2 thì subject là 'GDCD' và class là '6.2'. Nếu ô trống thì bỏ qua." }
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            dayOfWeek: { type: Type.NUMBER, description: "Thứ trong tuần, 2=Thứ Hai, 7=Thứ Bảy" },
            period: { type: Type.NUMBER },
            subject: { type: Type.STRING },
            class: { type: Type.STRING },
            isMorning: { type: Type.BOOLEAN }
          },
          required: ["dayOfWeek", "period", "subject", "isMorning"]
        }
      }
    }
  });
  
  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    return [];
  }
};

export const generateTimetableAI = async (constraints: string, assignments: string) => {
  const prompt = `
    DỰA TRÊN BẢNG PHÂN CÔNG GIÁO VIÊN:
    ${assignments}

    VÀ CÁC RÀNG BUỘC BỔ SUNG:
    ${constraints}

    HÃY TẠO THỜI KHÓA BIỂU MẪU (5 TIẾT/NGÀY, THỨ 2 - THỨ 6).
    Trả về định dạng JSON mảng.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: { 
      responseMimeType: "application/json",
      systemInstruction: "Bạn là chuyên gia quản lý đào tạo cấp cao. Chỉ trả về dữ liệu JSON hợp lệ, đảm bảo không trùng lịch giáo viên.",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            day: { type: Type.STRING },
            slots: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  period: { type: Type.NUMBER },
                  subject: { type: Type.STRING }
                },
                required: ["period", "subject"]
              }
            }
          },
          required: ["day", "slots"]
        }
      }
    }
  });
  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    return [];
  }
};

export const runAIAnalysisService = async () => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: "Dựa trên dữ liệu quản trị nhà trường, hãy đưa ra 3 đề xuất chiến lược để tối ưu hóa vận hành nhà trường.",
    config: {
      systemInstruction: "Bạn là chuyên gia tư vấn quản trị giáo dục cấp cao."
    }
  });
  return response.text;
};

export const generateAIComment = async (score: number, subject: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Viết 1 câu nhận xét sư phạm ngắn gọn cho học sinh được ${score} điểm môn ${subject}.`,
    config: { systemInstruction: SYSTEM_PROMPT }
  });
  return response.text || "";
};

export const generateLessonPlan = async (data: any) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Soạn giáo án theo mẫu Công văn 5512 môn ${data.subject} lớp ${data.grade}: ${data.title}. Mục tiêu: ${data.objectives}`,
    config: { systemInstruction: SYSTEM_PROMPT }
  });
  return response.text;
};

export const generatePPTLayout = async (title: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Tạo bố cục slide thuyết trình cho chủ đề: ${title}.`,
    config: { systemInstruction: SYSTEM_PROMPT }
  });
  return response.text;
};

export const generateTest7991 = async (data: any) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Soạn đề kiểm tra môn ${data.subject} lớp ${data.grade} chuẩn 7991.`,
    config: { systemInstruction: SYSTEM_PROMPT }
  });
  return response.text;
};
